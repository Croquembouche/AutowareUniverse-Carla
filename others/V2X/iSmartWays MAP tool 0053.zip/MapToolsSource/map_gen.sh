#!/bin/bash

echo Map Data Genarate............

intersection_id=$1
num=$2
interval=$3
length=$4
linknum=$5

if [ $intersection_id -gt 0 ];
then 
    echo unique id is $intersection_id
else
    echo Please enter a correct intersection id
    exit 
fi

if [ $num -gt 0 ];
then
    echo lane num is $num
else
    echo Please enter a correct lane num
    exit
fi

if [ $interval -gt 0 ];
then
    echo point interval is ${interval}m
else
    echo Please enter a correct point interval
    exit
fi

if [ $length -gt 0 ];
then
    echo lane length is ${length}m
else
    echo Please enter a correct lane length
    exit
fi

if [ $linknum -gt 0 ];
then
    echo link num is $linknum
else
    echo Please enter a correct link num
    exit
fi

NEMA_GNRMC="GNRMC"
NEMA_GPRMC="GPRMC"

dos2unix ./source/*

if [ ! -f "./source/ref_pt.log" ]; 
then
    echo error: ref_pt.log not exist
    exit
fi

NEMA_HEAD=`awk -F',' '{print $1}' ./source/ref_pt.log`
NEMA_FLAG=`echo ${NEMA_HEAD:1}`
echo ${NEMA_FLAG}

index=$((num-1))

if [ "$NEMA_FLAG" = "$NEMA_GNRMC" ]; 
then
    echo NEMA GNRMC FORMAT
    for i in $(seq 0 $index) 
    do  
        awk -F',' '$1=="$GNRMC"{print $4","$6}' ./source/$i.log > ./source/$i\_s.log
    done 
elif [ "$NEMA_FLAG" = "$NEMA_GPRMC" ];
then
    echo NEMA GPRMC FORMAT
    for i in $(seq 0 $index)
    do  
        awk -F',' '$1=="$GPRMC"{print $4","$6}' ./source/$i.log > ./source/$i\_s.log
    done 
else
echo ERROR: UNKOWN NEMA FORMAT
fi

if [ ! -f "lane.cfg" ]; 
then
    echo lane.cfg not exist
fi

for i in $(seq 0 $index)
do
   direction[$i]=`awk -F',' 'NR=='$i+2' {print $2}' lane.cfg`
done

for i in $(seq 0 $index)
do 
    if [ ${direction[$i]} -eq 1 ];
    then 
        awk -f reverse ./source/$i\_s.log > ./source/$i\_o.log
    elif [ ${direction[$i]} -eq 2 ];
    then 
        cp ./source/$i\_s.log  ./source/$i\_o.log
    else
        echo error: invalid lane direction
        exit
    fi 
done

echo ./MapTool -d${interval} -n${num} -i${intersection_id} -l${length} -k${linknum}
./MapTool -d${interval} -n${num} -i${intersection_id} -l${length} -k${linknum}

rm ./source/*_o.log
rm ./source/*_s.log

echo Map Data Genarate End