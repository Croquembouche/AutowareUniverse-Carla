#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <math.h>

#define TBL_CBGLINK_REF_POINT_FILE	"./MapData/TBL_CBGLINK_REF_POINT.csv"
#define TBL_CBGLINK_CONNECTIVITY_FILE	"./MapData/TBL_CBGLINK_CONNECTIVITY.csv"
#define TBL_CBGLINK_FILE			"./MapData/TBL_CBGLINK.csv"
#define MAP_CONFIG_FILE				"./MapData/map.cfg"
#define LANE_PHASE_FILE				"./MapData/lane_phase.cfg"

#define MAP_LANE_NUM	(64)
#define MAX_POINT_IN_LANE	(64)
#define PI 3.1415926535897
#define EARTH_RADIUS	(6371004)

typedef struct _point_2d_t{
	double latitude;
	double longitude;
}point_2d_t;

typedef struct _lane_info_t{
	int direction;
	int man;
	point_2d_t stop_line_ponit;
	int nPoint;
	point_2d_t points[MAX_POINT_IN_LANE];
}lane_info_t;

int gps_convert(double gps_lat, double gps_lng, double *lat, double *lng)
{	
    *lng = (int)(gps_lng/100) + (gps_lng/100.0 - (int)(gps_lng/100)) *100.0 / 60.0;
    *lat = (int)(gps_lat/100) + (gps_lat/100.0 - (int)(gps_lat/100)) *100.0 / 60.0;
    return 0;
}

double rad(double d) 
{ 
	return d * PI / 180.0; 
}

double getDistance(point_2d_t fisrt, point_2d_t cur) 
{ 
	double tmp_lat1, tmp_lng1;
	double tmp_lat2, tmp_lng2;
	gps_convert(fisrt.latitude, fisrt.longitude, &tmp_lat1, &tmp_lng1);
	gps_convert(cur.latitude, cur.longitude, &tmp_lat2, &tmp_lng2);

	double radLat1 = rad(tmp_lat1); 
	double radLat2 = rad(tmp_lat2); 
	double a = radLat1 - radLat2; 
	double b = rad(tmp_lng1) - rad(tmp_lng2); 
	double s = 2 * asin(sqrt(pow(sin(a/2),2) + cos(radLat1)*cos(radLat2)*pow(sin(b/2),2))); 

	s = s * EARTH_RADIUS; 
	s = round(s * 10000) / 10000; 
	return s; 
}


int getLaneCfg(lane_info_t lanes[MAP_LANE_NUM], int lane_num)
{
	int i = 0;
	char fileName[32] = {0};
	FILE* fp = NULL;
	char buffer[1024] = {0};
	char *str = NULL;

	fp = fopen("lane.cfg", "r");
	if(NULL == fp)
	{
		printf("error: can't open lane.cfg\n");
		return -1;
	}
	for(i=0; i<lane_num; i++)
	{
		memset(buffer, 0, 1024);
		while(fgets(buffer, 1024, fp))
		{
			if(buffer[0] != '#')
			{
				break;
			}
		}
		str = strtok(buffer, ",");
		str = strtok(NULL, ",");
		lanes[i].direction = atoi(str);
		str = strtok(NULL, ",");
		lanes[i].man = atoi(str);
	}

	fclose(fp);
	str = NULL;
	return 0;
}


int getLaneStopLinePoint(lane_info_t lanes[MAP_LANE_NUM], int lane_num)
{
	int i = 0;
	FILE* fp = NULL;
	char fileName[32] = {0};
	char buffer[1024] = {0};
	char *str = NULL;

	for(i=0; i<lane_num; i++)
	{
		memset(fileName, 0, sizeof(fileName));
		sprintf(fileName, "./source/%d_p.log", i);
		fp = fopen(fileName, "r");
		if(!fp)
		{
			printf("error: open %s fail\n", fileName);
			return -1;
		}

		memset(buffer, 0, 1024);
		if(fgets(buffer, 1024, fp))
		{
			str = strtok(buffer, ",");
			str = strtok(NULL, ",");
			str = strtok(NULL, ",");
			str = strtok(NULL, ",");
			lanes[i].stop_line_ponit.latitude = atof(str);
			str = strtok(NULL, ",");
			str = strtok(NULL, ",");
			lanes[i].stop_line_ponit.longitude = atof(str);
		}
		else
		{
			printf("error: read stop line file faild\n");
		}
		fclose(fp);

	}
}


int checkDistance(point_2d_t pre_point, point_2d_t cur_point, int interval)
{
	int ret = -1;
	double dist = 0;	
	
	dist = getDistance(pre_point, cur_point);
	if(dist >= interval)
	{
		printf("=== dist = %f\n", dist);
		ret = 0;
	}

	return ret;
}

int checkLength(point_2d_t cur_point, point_2d_t stop_line_ponit, int lane_length)
{
	int ret = -1;
	double dist = 0;

	dist = getDistance(cur_point, stop_line_ponit);
	//printf("dist to stop line = %f\n", dist);
	if(dist > lane_length)
	{
		ret = 0;
	}

	return ret;
}

int getLanePoints(lane_info_t lanes[MAP_LANE_NUM], int lane_num, int interval, int lane_length)
{
	int i = 0;
	FILE * fp = NULL;
	char fileName[32] = {0};
	point_2d_t pre_point = {0};
	point_2d_t cur_point = {0};
	char buffer[1024] = {0};
	char *str = NULL;
	int result = -1;
	int length_result = -1;

	for(i=0; i<lane_num; i++)
	{
		memset(fileName, 0, sizeof(fileName));
		sprintf(fileName, "./source/%d_o.log", i);
		fp = fopen(fileName, "r");
		if(!fp)
		{
			printf("error: open %s fail\n", fileName);
			return -1;
		}
		pre_point.latitude = lanes[i].stop_line_ponit.latitude;
		pre_point.longitude = lanes[i].stop_line_ponit.longitude;
		lanes[i].points[lanes[i].nPoint].latitude = pre_point.latitude;
		lanes[i].points[lanes[i].nPoint].longitude = pre_point.longitude;
		lanes[i].nPoint++;
		printf("-----> lane : %d <------\n ", i);
		while(fgets(buffer, 1024, fp))
		{
			str = strtok(buffer, ",");
			cur_point.latitude = atof(str);
			str = strtok(NULL, ",");
			cur_point.longitude = atof(str);
			result = checkDistance(pre_point, cur_point, interval);
			if(result == 0)
			{
				//printf("%f %f %f %f \n", cur_point.latitude, cur_point.longitude, lanes[i].stop_line_ponit.latitude, lanes[i].stop_line_ponit.longitude);
				length_result = checkLength(cur_point, lanes[i].stop_line_ponit, lane_length);
				if(length_result == 0)
				{
					break;
				}
				pre_point.latitude = cur_point.latitude;
				pre_point.longitude = cur_point.longitude;
				lanes[i].points[lanes[i].nPoint].latitude = cur_point.latitude;
				lanes[i].points[lanes[i].nPoint].longitude = cur_point.longitude;
				lanes[i].nPoint++;
			}
		}
		fclose(fp);
	}
}

void getRefPoint(point_2d_t *ref_pt)
{
	FILE* fp = NULL;
	char buffer[1024] = {0};
	char *str = NULL;

	fp = fopen("./source/ref_pt.log", "r");
	if(!fp)
	{
		printf("error: ref_pt.log open fail\n");
		return;
	}

	if(fgets(buffer, 1024, fp))
	{
		str = strtok(buffer, ",");
		str = strtok(NULL, ",");
		str = strtok(NULL, ",");
		str = strtok(NULL, ",");
		ref_pt->latitude = atof(str);
		str = strtok(NULL, ",");
		str = strtok(NULL, ",");
		ref_pt->longitude = atof(str);
	}

	fclose(fp);
}

void genMapDataFile(lane_info_t lanes[MAP_LANE_NUM], int lane_num, int id, int link_num)
{
	int i = 0, j = 0, k = 0;
	FILE *fp = NULL;
	int ret = -1;
	char buffer[1024] = {0};
	double distTo = 0, distFrom = 0;
	point_2d_t ref_pt = {0};
    double longitude = 0.0, latitude = 0.0;

	if(access("MapData", F_OK))
	{
		ret = mkdir("MapData", 0744);
		if(ret != 0)
		{
			printf("error: create MapData dir fail\n");
		}
	}

	fp = fopen(TBL_CBGLINK_CONNECTIVITY_FILE, "w+");
	if(!fp)
	{
		printf("error: %s create fail\n", TBL_CBGLINK_CONNECTIVITY_FILE);
	}
	fclose(fp);
	fp = NULL;

	fp = fopen(TBL_CBGLINK_REF_POINT_FILE, "w+");
	if(!fp)
	{
		printf("error: %s create fail\n", TBL_CBGLINK_REF_POINT_FILE);
	}

	for(i=0; i<lane_num; i++)
	{
		if(lanes[i].direction == 1)
		{
			for(j=lanes[i].nPoint-1; j>=0; j--)
			{
				distTo = getDistance(lanes[i].points[j], lanes[i].points[0]);
				distFrom = getDistance(lanes[i].points[j], lanes[i].points[lanes[i].nPoint-1]);
                gps_convert(lanes[i].points[j].latitude, lanes[i].points[j].longitude, &latitude, &longitude);
				memset(buffer, 0, 1024);
				sprintf(buffer, "%d, %d, %d, %0.1f,%0.1f, , ,%d, ,%0.7f,%0.7f, \n", 
					k++, i, lanes[i].nPoint-1-j, distFrom, distTo, 1, longitude, latitude);
				fwrite(buffer, strlen(buffer), 1,  fp);
			}
		}
		else if(lanes[i].direction == 2)
		{
			for(j=0; j<lanes[i].nPoint; j++)
			{
				distFrom = getDistance(lanes[i].points[j], lanes[i].points[0]);
				distTo = getDistance(lanes[i].points[j], lanes[i].points[lanes[i].nPoint-1]);
                gps_convert(lanes[i].points[j].latitude, lanes[i].points[j].longitude, &latitude, &longitude);
				memset(buffer, 0, 1024);
				sprintf(buffer, "%d, %d, %d, %0.1f,%0.1f, , ,%d, ,%0.7f,%0.7f, \n", 
					k++, i, j, distFrom, distTo, 1, longitude, latitude);
				fwrite(buffer, strlen(buffer), 1,  fp);
			}
		}
	}
	fclose(fp);
	fp = NULL;

	fp = fopen(TBL_CBGLINK_FILE, "w+");
	if(!fp)
	{
		printf("error: %s create fail\n", TBL_CBGLINK_FILE);
	}

	for(i=0; i<lane_num; i++)
	{
		memset(buffer, 0, 1024);
		sprintf(buffer, "%d, %d, %d, %d, %d\n", i, i, lanes[i].direction, lanes[i].man, i);
		fwrite(buffer, strlen(buffer), 1,  fp);
	}
	fclose(fp);
	fp = NULL;

    fp = fopen(LANE_PHASE_FILE, "w+");
	if(!fp)
	{
		printf("error: %s create fail\n", LANE_PHASE_FILE);
	}
    
    for(i=0; i<lane_num; i++)
    {
        memset(buffer, 0, 1024);
        sprintf(buffer, "lane%d=%d\n", i, i+1);
        fwrite(buffer, strlen(buffer), 1,  fp);
    }
    fclose(fp);
    fp = NULL;
    
	fp = fopen(MAP_CONFIG_FILE, "w+");
	if(!fp)
	{
		printf("error: %s create fail\n", MAP_CONFIG_FILE);
	}

	getRefPoint(&ref_pt);
    gps_convert(ref_pt.latitude, ref_pt.longitude, &latitude, &longitude);
	memset(buffer, 0, 1024);
	sprintf(buffer, "intersection, %d\n", id);
	fwrite(buffer, strlen(buffer), 1,  fp);

	memset(buffer, 0, 1024);
	sprintf(buffer, "latitude, %.7f\n", latitude);
	fwrite(buffer, strlen(buffer), 1,  fp);

	memset(buffer, 0, 1024);
	sprintf(buffer, "longitude, %.7f\n", longitude);
	fwrite(buffer, strlen(buffer), 1,  fp);

    memset(buffer, 0, 1024);
	sprintf(buffer, "link, %d\n", link_num);
	fwrite(buffer, strlen(buffer), 1,  fp);
    
	fclose(fp);
}

int main(int argc, char* argv[])
{
	int opt, i, j, k;
	int distanceThrehold = 0;
	int lane_num = 0, link_num = 0;
	int id = 0;
	int lane_length = 0;
	lane_info_t lanes[MAP_LANE_NUM] = {0};

	while((opt = getopt(argc, argv, "d:n:i:l:k:")) != -1){
		switch(opt){
			case 'd':
				distanceThrehold = atoi(optarg);
				printf("point interval = %d\n", distanceThrehold);
				break;
			case 'n':
				lane_num = atoi(optarg);
				printf("lane num = %d\n", lane_num);
				break;
			case 'i':
				id = atoi(optarg);
				printf("intersection id  = %d\n", id);
				break;
			case 'l':
				lane_length = atoi(optarg);
				printf("lane length  = %d\n", lane_length);
				break;
            case 'k':
			link_num = atoi(optarg);
			printf("link_num  = %d\n", link_num);
			break;
                
		}
	}
	
	if(distanceThrehold <= 0)
	{
		printf("Error: Please set correct point interval!\n");
		return -1;
	}

	if(lane_num <= 0)
	{
		printf("Error: Please set correct lane num!\n");
		return -1;
	}

	if(id <= 0)
	{
		printf("Error: Please set correct intersection id!\n");
		return -1;
	}

	if(lane_length <= 0)
	{
		printf("Error: Please set correct lane length!\n");
		return -1;
	}

	getLaneCfg(lanes, lane_num);
	getLaneStopLinePoint(lanes, lane_num);
	getLanePoints(lanes, lane_num, distanceThrehold, lane_length);
	for(i=0; i<lane_num; i++)
	{
		//printf("%d %d %f %f\n", lanes[i].direction, lanes[i].man, lanes[i].stop_line_ponit.latitude, lanes[i].stop_line_ponit.longitude);
		for(j=0; j<lanes[i].nPoint; j++)
		{
			//printf("%f %f\n", lanes[i].points[j].latitude, lanes[i].points[j].longitude);
		}
	}

	genMapDataFile(lanes, lane_num, id, link_num);
	return 0;
}